from turtle import *
from random import *
from math import *
import click
r1,g1,b1=0,0,0
r2,g2,b2=0,0,0


@click.command(context_settings={"help_option_names":['-h','--help']})
@click.option("-c1","--color1", default="160,82,45", help="branch's color,rgb separate with ','.")
@click.option("-c2","--color2", default="241,158,194", help="flower's color,rgb separate with ','.")
@click.option("-i2","--int1", default=10, help="color1's 进制.")
@click.option("-i2","--int2", default=10, help="flower's 进制.")
@click.option("-d","--deep", default=11, help="tree's iteration times.")
@click.option("-l","--length", default=100, help="branch's length.")
@click.option("-n","--name", default="tree", help="image's name.")
def main(color1, color2, int1, int2, deep, length, name):
    global r1
    global g1
    global b1
    global r2
    global g2
    global b2
    r1,g1,b1=(int(str(i),int1)/255-0.32 for i in color1.split(","))
    r2,g2,b2=(int(str(i),int2)/255-0.36 for i in color2.split(","))
    setup(1200,675,40,10) # 设置画布大小和位置
    bgcolor(0.5, 0.5, 0.5) # 设置背景颜色
    ht() # 隐藏画笔
    speed(0)
    tracer(60, 0) # 设置速度
    left(90) # 逆时针转90度使树朝上
    up() # 抬笔
    backward(300) # 向下走300个像素（现在笔的正方向是向上，位置为中心）
    tree(deep, length) # 画一颗迭代13层的最大长度100的树
    getcanvas().postscript(file=name+".eps")
    click.echo("保存成功，文件名为"+name+".eps")
    done()

def rgb(c):
    if c < 0: return 0
    if c > 1: return 1
    return c


def tree(n, l):
    pd() # 落笔
    t = cos(radians(heading() + 45)) / 8 + 0.25
    pencolor(rgb(r1+t), rgb(g1+t), rgb(b1+t))
    pensize(n / 4) # 随着结点的加深，笔触会越来越细
    forward(l) # 向前移动l吧
    if n > 0:
        b = randint(15,22)
        c = randint(15,22)
        d = l * (uniform(0.6,1))
        right(b)
        tree(n - 1, d)
        left(b + c)
        tree(n - 1, d)
        right(c)
    else:
        right(90)
        n = cos(radians(heading() - 45)) / 4 + 0.5
        pencolor(rgb(r2+n), rgb(g2+n), rgb(b2+n))
        circle(2)
        left(90)
    up() # 抬笔
    backward(l) # 回溯到画这笔之前的位置


if __name__=="__main__":
    main()
    
