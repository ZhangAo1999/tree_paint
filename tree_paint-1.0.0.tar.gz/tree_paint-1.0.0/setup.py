from setuptools import setup, find_packages
setup(
        name        = 'tree_paint',
        version     = '1.0.0',
        install_requires=['Click'],
		license='MIT',
		packages=find_packages(),
        author      = 'zhangAo',
        author_email= '804951563@qq.com',
        url         = 'http://xiaoao.space',
        description= 'draw a tree',
		zip_safe = True,
        entry_points={
        "console_scripts": ["tree=main.tree_paint:main"]
        }
)